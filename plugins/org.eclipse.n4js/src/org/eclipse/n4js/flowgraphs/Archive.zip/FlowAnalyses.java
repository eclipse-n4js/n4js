/**
 * Copyright (c) 2017 NumberFour AG.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *   NumberFour AG - Initial API and implementation
 */
package org.eclipse.n4js.flowgraphs;

import org.eclipse.n4js.flowgraphs.factories.ControlFlowGraphFactory;
import org.eclipse.n4js.flowgraphs.model.ControlFlowGraph;
import org.eclipse.n4js.n4JS.Script;

/**
 *
 */
public class FlowAnalyses {

	/**
	 *
	 */
	static public void perform(Script script) {
		/*
		 * Protect ASTPostprocessing from failures of flow analyses.
		 */
		try {
			_perform(script);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

	static private void _perform(Script script) {
		ControlFlowGraph cfg = ControlFlowGraphFactory.build(script);
	}

}

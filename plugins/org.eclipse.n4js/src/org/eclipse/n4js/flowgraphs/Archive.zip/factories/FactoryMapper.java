package org.eclipse.n4js.flowgraphs.factories;

import org.eclipse.n4js.n4JS.ControlFlowElement;
import org.eclipse.n4js.n4JS.ExpressionStatement;

/**
 *
 */
public class FactoryMapper {

	/**
	 *
	 */
	static public ControlFlowElement get(ControlFlowElement feature) {

		if (feature.getClass().equals(ExpressionStatement.class))
			return ((ExpressionStatement) feature).getExpression();

		return feature;
	}

}

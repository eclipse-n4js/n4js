package org.eclipse.n4js.flowgraphs.factories;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.n4js.flowgraphs.model.CatchToken;
import org.eclipse.n4js.flowgraphs.model.ComplexNode;
import org.eclipse.n4js.flowgraphs.model.JumpType;
import org.eclipse.n4js.flowgraphs.model.Node;
import org.eclipse.n4js.n4JS.GenericDeclaration;

class BlockFactory {

	static ComplexNode buildComplexNode(org.eclipse.n4js.n4JS.Block block) {
		ComplexNode cNode = new ComplexNode(block);

		Node entryNode = new Node("entry", block);
		Node exitNode = new Node("exit", block);
		Node blockNode = new Node("block", block);

		cNode.addNode(entryNode);
		cNode.addNode(blockNode);
		cNode.addNode(exitNode);

		List<Node> nodes = new LinkedList<>();
		nodes.add(entryNode);
		nodes.add(blockNode);
		nodes.add(exitNode);
		cNode.connectInternalSucc(nodes);

		cNode.setEntryNode(entryNode);
		cNode.setExitNode(exitNode);

		if (block.eContainer() instanceof GenericDeclaration) {
			exitNode.addCatchToken(new CatchToken(JumpType.Return));
			exitNode.addCatchToken(new CatchToken(JumpType.CatchesRuntimeExceptions));
		}

		return cNode;
	}

}

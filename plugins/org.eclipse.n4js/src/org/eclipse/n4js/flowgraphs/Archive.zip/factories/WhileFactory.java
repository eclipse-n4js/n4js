package org.eclipse.n4js.flowgraphs.factories;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.n4js.flowgraphs.model.CatchToken;
import org.eclipse.n4js.flowgraphs.model.ComplexNode;
import org.eclipse.n4js.flowgraphs.model.JumpType;
import org.eclipse.n4js.flowgraphs.model.Node;
import org.eclipse.n4js.n4JS.WhileStatement;

class WhileFactory {

	static ComplexNode buildComplexNode(WhileStatement whileStmt) {
		ComplexNode cNode = new ComplexNode(whileStmt);

		Node entryNode = new Node("entry", whileStmt);
		Node exitNode = new Node("exit", whileStmt);
		Node conditionNode = new Node("condition", whileStmt.getExpression());
		Node bodyNode = null;

		if (whileStmt.getStatement() != null) {
			bodyNode = new Node("body", whileStmt.getStatement());
		}

		cNode.addNode(entryNode);
		cNode.addNode(conditionNode);
		cNode.addNode(bodyNode);
		cNode.addNode(exitNode);

		List<Node> nodes = new LinkedList<>();
		nodes.add(entryNode);
		nodes.add(conditionNode);
		nodes.add(bodyNode);
		cNode.connectInternalSucc(nodes);
		cNode.connectInternalSucc(conditionNode, exitNode);

		LinkedList<Node> parts = ListUtils.filterNulls(bodyNode, conditionNode);
		cNode.connectInternalSuccLC(parts.getFirst(), conditionNode);

		cNode.setEntryNode(entryNode);
		cNode.setExitNode(exitNode);

		String label = ASTUtils.getLabel(whileStmt);
		exitNode.addCatchToken(new CatchToken(JumpType.Break, label));
		conditionNode.addCatchToken(new CatchToken(JumpType.Continue, label));
		cNode.setLoopContainer(true);

		return cNode;
	}

}

package org.eclipse.n4js.flowgraphs.model;

public enum EdgeType {

	op, ad, fd, se, dod, od, cd, io, init

}

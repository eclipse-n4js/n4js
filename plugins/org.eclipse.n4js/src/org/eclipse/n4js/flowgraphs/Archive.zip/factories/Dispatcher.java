package org.eclipse.n4js.flowgraphs.factories;

import java.lang.reflect.Method;

/**
 *
 */
public class Dispatcher {

	/**
	 * Use with care.
	 */
	@SuppressWarnings("unchecked")
	protected static <R, T> R dispatch(String name, T cfe) {
		R result = null;
		Class<?> cfeClass = cfe.getClass();
		Method[] methods = Dispatcher.class.getDeclaredMethods();
		for (Method m : methods) {
			Class<?>[] pTypes = m.getParameterTypes();
			boolean candidate = true;
			candidate &= m.getName().equals(name);
			candidate &= pTypes.length > 0 && pTypes[0].isAssignableFrom(cfeClass);
			if (candidate) {
				try {
					result = (R) m.invoke(null, cfe);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return result;
	}

}

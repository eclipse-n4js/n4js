package org.eclipse.n4js.flowgraphs.model;

public class DependencyEdge extends AbstractEdge {
	public final EdgeType type;
	public final Symbol symbol;
	public final boolean loopCarried;

	public DependencyEdge(EdgeType type, Node start, Node end) {
		this(type, start, end, null, false);
	}

	public DependencyEdge(EdgeType type, Node start, Node end, Symbol symbol, boolean loopCarried) {
		super(start, end);
		this.type = type;
		this.symbol = symbol;
		this.loopCarried = loopCarried;
	}

	@Override
	public String toString() {
		String s = "";
		s += start;
		s += "---" + type.toString().toUpperCase();
		s += ":" + symbol;
		if (loopCarried)
			s += "-|";
		s += "--->";
		s += end;
		return s;
	}

}

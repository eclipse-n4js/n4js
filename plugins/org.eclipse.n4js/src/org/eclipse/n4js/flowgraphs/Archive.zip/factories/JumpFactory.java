package org.eclipse.n4js.flowgraphs.factories;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.n4js.flowgraphs.model.ComplexNode;
import org.eclipse.n4js.flowgraphs.model.JumpToken;
import org.eclipse.n4js.flowgraphs.model.JumpType;
import org.eclipse.n4js.flowgraphs.model.Node;
import org.eclipse.n4js.n4JS.BreakStatement;
import org.eclipse.n4js.n4JS.ContinueStatement;
import org.eclipse.n4js.n4JS.Expression;
import org.eclipse.n4js.n4JS.ReturnStatement;
import org.eclipse.n4js.n4JS.Statement;
import org.eclipse.n4js.n4JS.ThrowStatement;

class JumpFactory {

	static ComplexNode buildComplexNode(BreakStatement stmt) {
		JumpToken jumptoken = new JumpToken(JumpType.Break, stmt.getLabel());
		return buildComplexNode(stmt, null, jumptoken);
	}

	static ComplexNode buildComplexNode(ContinueStatement stmt) {
		JumpToken jumptoken = new JumpToken(JumpType.Continue, stmt.getLabel());
		return buildComplexNode(stmt, null, jumptoken);
	}

	static ComplexNode buildComplexNode(ReturnStatement stmt) {
		JumpToken jumptoken = new JumpToken(JumpType.Return);
		return buildComplexNode(stmt, stmt.getExpression(), jumptoken);
	}

	static ComplexNode buildComplexNode(ThrowStatement stmt) {
		JumpToken jumptoken = new JumpToken(JumpType.Throw, stmt.getExpression());
		return buildComplexNode(stmt, stmt.getExpression(), jumptoken);
	}

	static ComplexNode buildComplexNode(Statement stmt, Expression expr, JumpToken jumptoken) {
		ComplexNode cNode = new ComplexNode(stmt);

		Node startNode = new Node("entry", stmt);
		Node endNode = new Node("exit", stmt);
		Node expression = null;

		cNode.addNode(startNode);

		if (expr != null) {
			expression = new Node("expression", expr);
			cNode.addNode(expression);
		}
		cNode.addNode(endNode);

		List<Node> cfs = new LinkedList<>();
		cfs.add(startNode);
		cfs.add(expression);
		cfs.add(endNode);
		cNode.connectInternalSucc(cfs);

		cNode.setEntryNode(startNode);
		cNode.setExitNode(endNode);

		endNode.addJumpToken(jumptoken);

		return cNode;
	}

}

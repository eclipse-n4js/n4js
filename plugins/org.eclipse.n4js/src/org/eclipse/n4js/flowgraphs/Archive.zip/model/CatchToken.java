package org.eclipse.n4js.flowgraphs.model;

public class CatchToken extends JumpToken {

	public CatchToken(JumpType type) {
		this(type, null);
	}

	public CatchToken(JumpType type, Object id) {
		super(type, id);
	}

}

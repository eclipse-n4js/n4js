package org.eclipse.n4js.flowgraphs.factories;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.n4js.flowgraphs.model.ComplexNode;
import org.eclipse.n4js.flowgraphs.model.Node;
import org.eclipse.n4js.n4JS.Expression;

class ExpressionFactory {

	static ComplexNode buildComplexNode(Expression expr) {
		ComplexNode cNode = new ComplexNode(expr);

		Node entryNode = new Node("entry", expr);
		Node exitNode = new Node("exit", expr);
		List<Node> argumentNodes = new LinkedList<>();

		List<Expression> args = ControlFlowChildren.get(expr);
		for (Expression arg : args) {
			Node argNode = new Node("arg_" + args.indexOf(arg), arg);
			argumentNodes.add(argNode);
		}

		cNode.addNode(entryNode);
		for (Node arg : argumentNodes)
			cNode.addNode(arg);
		cNode.addNode(exitNode);

		List<Node> nodes = new LinkedList<>();
		nodes.add(entryNode);
		nodes.addAll(argumentNodes);
		nodes.add(exitNode);
		cNode.connectInternalSucc(nodes);

		cNode.setEntryNode(entryNode);
		cNode.setExitNode(exitNode);

		return cNode;
	}

}

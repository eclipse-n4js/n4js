package org.eclipse.n4js.flowgraphs.model;

abstract public class AbstractEdge implements GraphElement {
	public final Node start;
	public final Node end;

	public AbstractEdge(Node start, Node end) {
		this.start = start;
		this.end = end;
	}

}

package org.eclipse.n4js.flowgraphs.model;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.n4js.n4JS.ControlFlowElement;

public class ProgramAbstraction {
	final public BodyDeclaration bodyDeclaration;
	final public Map<ASTNode, ControlFlowElement> astNodeMap = new HashMap<>();

	public ProgramAbstraction(BodyDeclaration md) {
		this.bodyDeclaration = md;
	}

}

package org.eclipse.n4js.flowgraphs.model;

public class ControlFlowEdge extends AbstractEdge {
	public final boolean isLoop;
	public final boolean isJump;
	public final boolean isNested;

	public ControlFlowEdge(Node start, Node end) {
		this(start, end, false, false, false);
	}

	public ControlFlowEdge(Node start, Node end, boolean isLoop) {
		this(start, end, isLoop, false, false);
	}

	public ControlFlowEdge(Node start, Node end, boolean isLoop, boolean isBreak) {
		this(start, end, isLoop, isBreak, false);
	}

	public ControlFlowEdge(Node start, Node end, boolean isLoop, boolean isBreak, boolean nested) {
		super(start, end);
		this.isLoop = isLoop;
		this.isJump = isBreak;
		this.isNested = nested;
	}

	@Override
	public String toString() {
		String s = " (" + start + ") ";
		if (isLoop)
			s += "-lc";
		if (isJump)
			s += "-bc";
		s += "-> ";
		s += "(" + end + ")";
		return s;
	}
}

package org.eclipse.n4js.flowgraphs.model;

/**
 *
 */
@SuppressWarnings("javadoc")
public enum JumpType {
	Return, Throw, Break, Continue, CatchesAll, CatchesRuntimeExceptions

}

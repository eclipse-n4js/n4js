package org.eclipse.n4js.flowgraphs.factories;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.n4js.flowgraphs.model.ComplexNode;
import org.eclipse.n4js.flowgraphs.model.Node;
import org.eclipse.n4js.n4JS.IfStatement;

class IfFactory {

	static ComplexNode buildComplexNode(IfStatement ifStmt) {
		ComplexNode cNode = new ComplexNode(ifStmt);

		Node entryNode = new Node("entry", ifStmt);
		Node exitNode = new Node("exit", ifStmt);
		Node conditionNode = new Node("condition", ifStmt.getExpression());
		Node thenBlock = null;
		Node elseBlock = null;

		if (ifStmt.getIfStmt() != null)
			thenBlock = new Node("then", ifStmt.getIfStmt());
		if (ifStmt.getElseStmt() != null)
			elseBlock = new Node("else", ifStmt.getElseStmt());

		cNode.addNode(entryNode);
		cNode.addNode(conditionNode);
		cNode.addNode(thenBlock);
		cNode.addNode(elseBlock);
		cNode.addNode(exitNode);

		List<Node> nodes = new LinkedList<>();
		nodes.add(entryNode);
		nodes.add(conditionNode);
		nodes.add(thenBlock);
		nodes.add(exitNode);
		cNode.connectInternalSucc(nodes);

		if (ifStmt.getElseStmt() == null) {
			cNode.connectInternalSucc(conditionNode, exitNode);
		} else {
			cNode.connectInternalSucc(conditionNode, elseBlock, exitNode);
		}

		cNode.setEntryNode(entryNode);
		cNode.setExitNode(exitNode);

		return cNode;
	}

}

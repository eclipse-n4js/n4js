package org.eclipse.n4js.flowgraphs.factories;

import java.util.LinkedList;
import java.util.List;

import org.eclipse.n4js.flowgraphs.model.ComplexNode;
import org.eclipse.n4js.flowgraphs.model.Node;
import org.eclipse.n4js.n4JS.VariableDeclaration;

class VariableDeclaratorFactory {

	static ComplexNode buildComplexNode(VariableDeclaration varDecl) {
		ComplexNode cNode = new ComplexNode(varDecl);

		Node entryNode = new Node("entry", varDecl);
		Node exitNode = new Node("exit", varDecl);
		Node initNode = null;

		if (varDecl.getExpression() != null) {
			initNode = new Node("initializer", varDecl.getExpression());
		}

		cNode.addNode(entryNode);
		cNode.addNode(initNode);
		cNode.addNode(exitNode);

		List<Node> nodes = new LinkedList<>();
		nodes.add(entryNode);
		nodes.add(initNode);
		nodes.add(exitNode);
		cNode.connectInternalSucc(nodes);

		cNode.setEntryNode(entryNode);
		cNode.setExitNode(exitNode);

		// entryNode.setDeclaratedTokens(varDecl); // TODO: Declare-Effect

		return cNode;
	}

}

package org.eclipse.n4js.flowgraphs.model;

import java.util.List;

import org.eclipse.n4js.flowgraphs.factories.JavaFeatures;

public class Graph {
	final public ProgramBlock program;
	final public JavaFeatures javaFeatures;
	final public EffectMap effectMap = new EffectMap();
	final public Hierarchy hierarchy = new Hierarchy();

	public Graph(ProgramBlock program, JavaFeatures featureMap) {
		this.program = program;
		this.javaFeatures = featureMap;
	}

	public List<Block> getAllBlocks() {
		return program.getMethodCNode().getBlocksTransitive(javaFeatures);
	}
}

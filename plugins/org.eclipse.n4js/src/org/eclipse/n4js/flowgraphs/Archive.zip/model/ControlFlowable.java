package org.eclipse.n4js.flowgraphs.model;

import org.eclipse.n4js.n4JS.ControlFlowElement;

public interface ControlFlowable extends GraphElement {

	public Node getEntry();

	public Node getExit();

	public ControlFlowElement getControlFlowElement();

}

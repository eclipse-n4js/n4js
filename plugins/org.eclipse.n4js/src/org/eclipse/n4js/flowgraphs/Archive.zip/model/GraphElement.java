package org.eclipse.n4js.flowgraphs.model;

public interface GraphElement {

}

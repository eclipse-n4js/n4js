package org.eclipse.n4js.flowgraphs.model;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


import java17.ast.JavaFeature;

public class GraphSystem {
	final public List<PartialGraph> partialGraphs = new LinkedList<>();
	final public Set<Symbol> symbols = new HashSet<>();
	final public Map<JavaFeature, List<ComplexNode>> featuresToCNodes = new HashMap<>();
	final public Map<Symbol, ComplexNode> symbolToDeclaration = new HashMap<>();

	public void init(Graph graph) {
		featuresToCNodes.clear();
		symbolToDeclaration.clear();

		// register all clones
		for (PartialGraph pg : partialGraphs) {
			for (ComplexNode cn : pg.cnodes) {
				ControlFlowElement cfe = cn.astElement;
				if (!featuresToCNodes.containsKey(cfe)) {
					List<ComplexNode> clones = new LinkedList<>();
					featuresToCNodes.put(cfe, clones);
				}
				List<ComplexNode> clones = featuresToCNodes.get(cfe);
				clones.add(cn);
			}
		}

		// register all declarations
		for (PartialGraph pg : partialGraphs) {
			for (ComplexNode cn : pg.cnodes) {
				for (Symbol s : cn.getDeclaringSymbols(graph)) {
					symbolToDeclaration.put(s, cn);
				}
			}
		}

		// find all dependency edges
		List<DependencyEdge> depEdges = new LinkedList<>();
		for (PartialGraph pg : partialGraphs)
			depEdges.addAll(pg.depEdges);

		// find all symbols
		for (DependencyEdge edge : depEdges) {
			if (edge.symbol != null)
				symbols.add(edge.symbol);
		}
	}

}
